package mypackage;

public class Circle extends Shape {

	@Override
	void draw() {
		System.out.println("Drawing a circle...");
	}

}

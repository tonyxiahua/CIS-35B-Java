package mypackage;

public interface Flying {
	public void fly(); 
}

/* Packages */

package mypackage;

public class Program1 {
	public Program1(){
		// default constructor
	}
	
	public void method1()
	{
		// empty method
	}
	
	public void method2()
	{
		// empty method
	}
	
}

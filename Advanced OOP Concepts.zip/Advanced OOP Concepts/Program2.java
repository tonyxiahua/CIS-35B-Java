/* Packages */

package mypackage;

public class Program2 {
	public Program2(){
		// default constructor
	}
	
	public void method1()
	{
		// empty method
	}
	
	public void method2()
	{
		// empty method
	}
	
}
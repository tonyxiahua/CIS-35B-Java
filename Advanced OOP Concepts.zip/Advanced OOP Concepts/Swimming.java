package mypackage;

public interface Swimming {
	public void swim();
}
